
/*
 * Copyright (C) 2024 NexusTeam.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Developed by NexusTeam.
 * © 2024™
 */

package android.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class NexusPopuper {

    private final Context context;
    private final View anchorView;
    private final List<PopupMenuItem> items = new ArrayList<>();
    private OnMenuItemClickListener onMenuItemClickListener;
    private String title;
    
    public interface OnMenuItemClickListener {
        void onItemClick(int position, PopupMenuItem item);
    }

    public static class PopupMenuItem {
        String text;
        Drawable icon;

        public PopupMenuItem(String text, @DrawableRes int iconResId, Context context) {
            this.text = text;
            this.icon = ContextCompat.getDrawable(context, iconResId);
        }

        public String getText() {
            return text;
        }

        public Drawable getIcon() {
            return icon;
        }
    }

    public NexusPopuper(@NonNull Context context, @NonNull View anchorView) {
        this.context = context;
        this.anchorView = anchorView;
    }

    public NexusPopuper setTitle(@StringRes int titleResId) {
        this.title = context.getString(titleResId);
        return this;
    }

    public NexusPopuper setTitle(String title) {
        this.title = title;
        return this;
    }

    public NexusPopuper addItem(String text, @DrawableRes int iconResId) {
        items.add(new PopupMenuItem(text, iconResId, context));
        return this;
    }

    public NexusPopuper setOnMenuItemClickListener(OnMenuItemClickListener listener) {
        this.onMenuItemClickListener = listener;
        return this;
    }

    public void show() {
    // Create the root layout for the popup
    LinearLayout popupLayout = new LinearLayout(context);
    popupLayout.setOrientation(LinearLayout.VERTICAL);
    popupLayout.setPadding(16, 16, 16, 16);

    // Add title if set
    if (title != null) {
        TextView titleView = new TextView(context);
        titleView.setText(title);
        titleView.setTextAppearance(android.R.style.TextAppearance_Material_Headline);
        popupLayout.addView(titleView);
    }

    // Add each menu item with a custom layout
    for (int i = 0; i < items.size(); i++) {
        PopupMenuItem item = items.get(i);

        // Create an item layout
        LinearLayout itemLayout = new LinearLayout(context);
        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
        itemLayout.setPadding(8, 8, 8, 8);
        itemLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Create and add icon if available
        if (item.getIcon() != null) {
            ImageView iconView = new ImageView(context);
            iconView.setImageDrawable(item.getIcon());
            iconView.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            iconView.setPadding(8, 0, 16, 0);
            itemLayout.addView(iconView);
        }

        // Create and add text view for item label
        TextView itemText = new TextView(context);
        itemText.setText(item.getText());
        itemText.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        itemLayout.addView(itemText);

        // Set up click listener for the item
        final int position = i;
        itemLayout.setOnClickListener(v -> {
            if (onMenuItemClickListener != null) {
                onMenuItemClickListener.onItemClick(position, item);
            }
        });

        // Add the item layout to the popup layout
        popupLayout.addView(itemLayout);
    }

    // Create and display the popup window
    PopupWindow popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
    popupWindow.setOutsideTouchable(true);
    popupWindow.setFocusable(true);
    popupWindow.showAsDropDown(anchorView);
   }
}