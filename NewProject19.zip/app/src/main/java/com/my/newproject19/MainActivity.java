
/**
Apni chhoti si madad se kisi ki zindagi mein bada farq laa sakte hain. Aaj hi donate karein aur apne dil mein insaniyat ka rang bharain.

Jab hum apne ek chhote se yogdan se kisi ki zindagi mein roshni bharte hain, toh sach mein humari duniya bhi roshan ho jaati hai. Aaj, apni madad se kisi ki zindagi mein farq laiye. Aapka ek chhota sa kadam, kisi ki muskurahat ka wajah ban sakta hai. Donate karein, aur insaniyat ke safar mein apna yogdan de.

9638884271@fam

nexusteam.suppoet@myyahoo.com

or

nexusnet95@gmail.com

*English
With your small contribution, you can make a big difference in someone's life. Donate today and fill your heart with the color of humanity.

When we light up someone's life with our small contribution, we also illuminate our own world. Today, make a difference in someone's life with your support. Your small step can become the reason for a smile. Donate now and be a part of humanity's journey.

9638884271@fam

nexusteam.suppoet@myyahoo.com

or

nexusnet95@gmail.com

**/

/*
 * Copyright (C) 2024 NexusTeam.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Developed by NexusTeam.
 * © 2024™
 */

package com.my.newproject19;


import android.widget.NexusPopuper;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(android.R.layout.simple_list_item_1);  // using a simple layout with one TextView

        // Initialize the TextView
        textView1 = findViewById(android.R.id.text1);
        textView1.setText("Click here to open NexusPopuper");

        // Set click listener on TextView to open NexusPopuper
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNexusPopuper();
            }
        });
    }

    private void showNexusPopuper() {
        // Initialize NexusPopuper
        NexusPopuper nexusPopuper = new NexusPopuper(this, textView1);
        nexusPopuper
            .setTitle("Options")
            .addItem("Settings", android.R.drawable.ic_menu_preferences)
            .addItem("Share", android.R.drawable.ic_menu_share)
            .addItem("Help", android.R.drawable.ic_menu_help)
            .setOnMenuItemClickListener(new NexusPopuper.OnMenuItemClickListener() {
                @Override
                public void onItemClick(int position, NexusPopuper.PopupMenuItem item) {
                    // Show a toast based on the clicked item
                    String message = "Clicked: " + item.getText();
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            })
            .show();
    }
}
